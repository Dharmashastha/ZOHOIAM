package test;

import common.CustomException;
import common.InputCenter;
import zcoin.CustomerDetails;
import zcoin.ZcoinLogic;

public class Controller {
	
	InputCenter inputCall = new InputCenter();
	ZcoinLogic zcoinCall = new ZcoinLogic();
	
	public void customerDetails() throws CustomException
	{
		CustomerDetails cusCall = new CustomerDetails();
		System.out.println("Enter the Full Name");
		cusCall.setFullName(inputCall.getString());
		System.out.println("Enter the Email-ID");
		cusCall.setEmailId(inputCall.getString());
		System.out.println("Enter the Mobile Number");
		cusCall.setMobileNumber(inputCall.getLong());
		System.out.println("Enter the GovtID");
		cusCall.setGovtId(inputCall.getLong());
		System.out.println("Enter the Password");
		String password = inputCall.getString();
		while(!zcoinCall.checkPassword(cusCall, password))
		{
			System.out.println("Enter the Password");
			password = inputCall.getString();
			zcoinCall.checkPassword(cusCall, password);
		}
		cusCall.setPassword(password);
		System.out.println("Enter the Initial Real Currency (RC) Deposit");
		cusCall.setRcDeposit(inputCall.getDouble());
		zcoinCall.addCustomerDeatils(cusCall);
	}
	
	public void login() throws CustomException
	{
		System.out.println("Enter the UserID");
		String userId = inputCall.getString();
		System.out.println("Enter the Password");
		String password = inputCall.getString();
		if(zcoinCall.checkLogin(userId, password))
		{
			System.out.println("WELCOME THE ZCOIN");
		}
		else
		{
			System.out.println("Your UserID and Password Wrong");
		}
	}
	
	public static void main(String[] args) {
		
		Controller conCall = new Controller();
		
		boolean flag = false;
		
		while(!flag)
		{
			System.out.println("1.ZCOIN SignUp");
			System.out.println("2.ZCOIN LOGIN");
			int choice = 0;
			try {
				choice = conCall.inputCall.getInt();
			} catch (CustomException e) {
				System.out.println(e.getMessage());
				//e.printStackTrace();
			}
			switch(choice)
			{
				case 1:
				{
					try {
						conCall.customerDetails();
					} catch (CustomException e) {
						e.printStackTrace();
					}
					break;
				}
				case 2:
				{
					try {
						conCall.login();
					} catch (CustomException e) {
						e.printStackTrace();
					}
					break;
				}
				case 3:
				{
					
					break;
				}
				default:
				{
					System.out.println("");
					break;
				}
			}
		}
	}

}
