package zcoin;

public class TransactionDetails {

	private long fromZID;
	private long toZID;
	private String dateAndTime;
	private boolean transactionType;

	public long getFromZID() {
		return fromZID;
	}

	public void setFromZID(long fromZID) {
		this.fromZID = fromZID;
	}

	public long getToZID() {
		return toZID;
	}

	public void setToZID(long toZID) {
		this.toZID = toZID;
	}

	public String getDateAndTime() {
		return dateAndTime;
	}

	public void setDateAndTime(String dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	public boolean isTransactionType() {
		return transactionType;
	}

	public void setTransactionType(boolean transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "TransactionDetails [fromZID=" + fromZID + ", toZID=" + toZID + ", dateAndTime=" + dateAndTime
				+ ", transactionType=" + transactionType + "]";
	}

}
