package zcoin;

public class ZIDetails {

	private String emailId;
	private long zID;
	private TransactionDetails transCall;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getZID() {
		return zID;
	}

	public void setZID(long zID) {
		this.zID = zID;
	}

	public TransactionDetails getTransCall() {
		return transCall;
	}

	public void setTransCall(TransactionDetails transCall) {
		this.transCall = transCall;
	}

	@Override
	public String toString() {
		return "ZIDetails [emailId=" + emailId + ", zID=" + zID + ", transCall=" + transCall + "]";
	}

}
