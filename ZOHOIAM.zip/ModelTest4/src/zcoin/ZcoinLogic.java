package zcoin;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import common.CustomException;

public class ZcoinLogic {
	
	Map<String,CustomerDetails> customerStore = new HashMap<>();
	Map<Long,ZIDetails> zIDStore = new HashMap<>();
	
	private void checker(String checkString) throws CustomException {
		if(Objects.isNull(checkString) || checkString.isEmpty())
		{
			throw new CustomException("Data is Empty/Null");
		}
	}
	
	public void checkerCustomer(CustomerDetails checkCall) throws CustomException
	{
		if(Objects.isNull(checkCall))
		{
			throw new CustomException("CustomerDeatils is Null");
		}
	}
	
	public void checkerZID(ZIDetails checkCall) throws CustomException
	{
		if(Objects.isNull(checkCall))
		{
			throw new CustomException("ZIDDeatils is Null");
		}
	}
	
	
	public void addCustomerDeatils(CustomerDetails cusCall) throws CustomException
	{
		checkerCustomer(cusCall);
		customerStore.put(cusCall.getEmailId(), cusCall);
	}
	
	public void addZIDDeatils(ZIDetails zidCall) throws CustomException
	{
		checkerZID(zidCall);
		zIDStore.put(zidCall.getZID(), zidCall);
	}
	
	public boolean checkPassword(CustomerDetails cusCall,String password) throws CustomException
	{
		checker(password);
		//|| Long.parseLong(password) == cusCall.getMobileNumber()
		if(password.length() < 8 || password.contains(cusCall.getFullName()) 
		|| password.contains(cusCall.getEmailId()) 
		|| password.matches("!#%><@&*"))
		{
			return false;
		}
	return true;	
	}
	
	public boolean checkLogin(String UserId,String password) throws CustomException
	{
		checker(UserId);
		checker(password);
		CustomerDetails cusCall = customerStore.get(UserId);
		checkerCustomer(cusCall);
		if(cusCall.getEmailId().equals(UserId) || cusCall.getPassword().equals(password))
		{
			return true;
		}
	return false;	
	}
	
}
