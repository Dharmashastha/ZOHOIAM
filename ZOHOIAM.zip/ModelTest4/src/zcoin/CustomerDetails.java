package zcoin;

public class CustomerDetails {

	private String fullName;
	private String emailId;
	private long mobileNumber;
	private long govtId;
	private String password;
	private double rcDeposit;
	private boolean zidStatus = false;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public long getGovtId() {
		return govtId;
	}

	public void setGovtId(long govtId) {
		this.govtId = govtId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getRcDeposit() {
		return rcDeposit;
	}

	public void setRcDeposit(double rcDeposit) {
		this.rcDeposit = rcDeposit;
	}

	public boolean isZidStatus() {
		return zidStatus;
	}

	public void setZidStatus(boolean zidStatus) {
		this.zidStatus = zidStatus;
	}

	@Override
	public String toString() {
		return "CustomerDetails [fullName=" + fullName + ", emailId=" + emailId + ", mobileNumber=" + mobileNumber
				+ ", govtId=" + govtId + ", password=" + password + ", rcDeposit=" + rcDeposit + ", zidStatus="
				+ zidStatus + "]";
	}

}
