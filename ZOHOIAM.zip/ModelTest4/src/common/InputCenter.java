package common;

import java.util.Objects;
import java.util.Scanner;

public class InputCenter {
	
	Scanner inputCall = new Scanner(System.in);

public void checker(String checkString) throws CustomException
{
	if(Objects.isNull(checkString) || checkString.isEmpty())
	{
		throw new CustomException("Input is Empty/Null");
	}
}

public String getString() throws CustomException
{
	String inputString = "";
	
	try {
		inputString = inputCall.nextLine();
		checker(inputString);
	}
	catch (CustomException e) {
		System.out.println(e.getMessage());
	}
return inputString;		
}

public int getInt() throws CustomException
{
	int inputInt = 0;
	
	try {
		String inputString = inputCall.nextLine();
		checker(inputString);
		inputInt = Integer.parseInt(inputString);
	}
	catch (CustomException e) {
		System.out.println(e.getMessage());
	}
return inputInt;		
}

public double getDouble() throws CustomException
{
	double inputDouble = 0.00;
	
	try {
		String inputString = inputCall.nextLine();
		checker(inputString);
		inputDouble = Double.parseDouble(inputString);
	}
	catch (CustomException e) {
		System.out.println(e.getMessage());
	}
return inputDouble;		
}

public long getLong() throws CustomException
{
	long inputLong = 0l;
	
	try {
		String inputString = inputCall.nextLine();
		checker(inputString);
		inputLong = Long.parseLong(inputString);
	}
	catch (CustomException e) {
		System.out.println(e.getMessage());
	}
return inputLong;		
}

}
