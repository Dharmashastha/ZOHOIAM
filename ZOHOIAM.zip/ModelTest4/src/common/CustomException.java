package common;

public class CustomException extends Exception{

	public CustomException(Exception e)
	{
		super(e);
	}
	
	public CustomException(String message)
	{
		super(message);
	}
}
