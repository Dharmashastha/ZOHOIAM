package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Distinct {

	public int getIndex(int array1[], int array2[]) {
		/*List<Integer> output = new ArrayList<>();

		int minIndex = -1;

		for (int i = 0; i < array1.length; i++) {
			if (!output.contains(array1[i])) {
				//minIndex = i;
				output.add(array1[i]);
			}
		}

		for (int i = 0; i < array2.length; i++) {
			if (!output.contains(array2[i])) {
				minIndex = i;
				return minIndex;
			}
		}

		return minIndex;*/
		int len1 = array1.length;
		int len2 = array2.length;
		int len;
		if(len1>len2) {
			len = len1;
		}
		else {
			len = len2;
		}
		for(int i=0; i<len;i++) {
			if(array1[i] != array2[i] ) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {

		Distinct distinctCall = new Distinct();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the Array1 data Length");
		int length1 = Integer.parseInt(input.nextLine());

		int array1[] = new int[length1];

		System.out.println("Enter the Array1 data");

		for (int i = 0; i < length1; i++) {
			array1[i] = Integer.parseInt(input.nextLine());
		}

		System.out.println("Enter the Array2 data Length");
		int length2 = Integer.parseInt(input.nextLine());

		int array2[] = new int[length2];

		System.out.println("Enter the Array data");

		for (int i = 0; i < length2; i++) {
			array2[i] = Integer.parseInt(input.nextLine());
		}

		System.out.println(distinctCall.getIndex(array1, array2));
		input.close();
	}

}
