package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.TreeMap;

public class AbsoluteDifference {

	public int[] absoluteDifference(int array[], int n, int k) {
		TreeMap<Integer, List<Integer>> output = new TreeMap<>();
		List<Integer> saved = null;
		for (int i = 0; i < n; i++) {

			int temp = Math.abs(k - array[i]);
			if (output.containsKey(temp)) {
				saved = output.get(temp);
				saved.add(array[i]);
				output.put(temp, saved);
			} else {
				saved = new ArrayList<>();
				saved.add(array[i]);
				output.put(temp, saved);
			}
		}
		int j = 0;
		for (int dummy : output.keySet()) {
			List<Integer> answer = output.get(dummy);
			int size = answer.size();

			for (int i = 0; i < size; i++) {
				array[j++] = answer.get(i);
			}
		}
		return array;
	}

	public static void main(String[] args) {

		AbsoluteDifference abCall = new AbsoluteDifference();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the Array data Length");
		int length = Integer.parseInt(input.nextLine());

		int array[] = new int[length];

		System.out.println("Enter the Array data");

		for (int i = 0; i < length; i++) {
			array[i] = Integer.parseInt(input.nextLine());
		}

		System.out.println("Enter the K Value");
		int k = Integer.parseInt(input.nextLine());

		System.out.println(Arrays.toString(abCall.absoluteDifference(array, length, k)));
		input.close();
	}

}
