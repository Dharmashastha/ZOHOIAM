package test;

import java.util.Scanner;

public class BinarySearchTree {

	public Node insert(Node root, int value) {
		if (root == null) {
			return new Node(value);
		}

		if (value < root.data) {
			root.left = insert(root.left, value);
		}
		if (value > root.data) {
			root.right = insert(root.right, value);
		}
		return root;
	}

	public int minData(Node root) {
		if (root == null) {
			return -1;
		}

		int minValue = root.data;

		while (root.left != null) {
			minValue = root.left.data;
			root = root.left;
		}
		return minValue;
	}

	public static void main(String[] args) {

		BinarySearchTree treeCall = new BinarySearchTree();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the Node data");
		Node nodeCall = new Node(Integer.parseInt(input.nextLine()));

		System.out.println("Enter the Node data Length");
		int length = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Node data");

		for (int i = 0; i < length; i++) {
			treeCall.insert(nodeCall, Integer.parseInt(input.nextLine()));
		}
		
		System.out.println(nodeCall);
		
		System.out.println("MinValue :" + treeCall.minData(nodeCall));
		input.close();
	}

}
