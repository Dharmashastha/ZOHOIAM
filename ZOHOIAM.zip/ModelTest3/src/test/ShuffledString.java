package test;

import java.util.Objects;
import java.util.Scanner;

public class ShuffledString {

	public String shuffledString(int indices[],String str) throws Exception
	{
		if(Objects.isNull(str) || str.isEmpty())
		{
			throw new Exception("String is Null/Empty");
		}
		StringBuilder ans = new StringBuilder(str);
		//char newChar[] = new char[indices.length];
		for(int i = 0; i < indices.length; i++)
		{
			ans.setCharAt(indices[i], str.charAt(i));
			//newChar[indices[i]] = str.charAt(i);
		}
		//String.valueOf(newChar)
	return ans.toString();	
	}
	
//	static double pow(Long x,int i)
//    {
//        if(i == 0)
//        {
//            return 1;
//        }
//        double output = 1;
//        int k = 0;
//        while(k < i)
//        {
//            output *= x;
//            //System.out.println(output);
//            k++;
//        }
//    return output;    
//    }
	
	public static void main(String[] args) {
		ShuffledString shuCall = new ShuffledString();
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the Array Length");
		int length = Integer.parseInt(input.nextLine());
		
		int array[] = new int[length];
		System.out.println("Enter the Array Data");
		for(int i = 0; i < length; i++)
		{
			array[i] = Integer.parseInt(input.nextLine());
		}
		System.out.println("Enter the String");
		String str = input.nextLine();
		try {
			System.out.println(shuCall.shuffledString(array, str));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		//System.out.println(ShuffledString.pow(0l, 2));
	input.close();	
	}

}
