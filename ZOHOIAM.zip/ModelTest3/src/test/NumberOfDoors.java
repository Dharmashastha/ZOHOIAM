package test;

import java.util.Scanner;

public class NumberOfDoors {
	
	public long numberOfDoors(long number)
	{
		
//		double x = number/2.0;
//		double saved = 0;
//		
//		while(x != 0)
//		{
//			saved = x;
//			x = number / 2.0 + number / saved; 
//		}
//		System.out.println(x);
		return (long)Math.sqrt(number);
	}
	
	public static void main(String[] args) {
		
		NumberOfDoors doorCall = new NumberOfDoors();
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the number of doors");
		
		int number = Integer.parseInt(input.nextLine());
		
		System.out.println(doorCall.numberOfDoors(number));
	input.close();	
	}

}
