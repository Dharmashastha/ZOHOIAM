package mathematical;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Solution 
{
	int count = 0;
public int palindrome(int number)
{
	return getPalindrome(number, 10);
}

public int getPalindrome(int number,int value)
{	
	StringBuilder ans = new StringBuilder(value+"");

	if(Integer.parseInt(ans.reverse().toString()) == value)
	{
		count++;
	}
	
	if(number == count)
	{
		return value;
	}
	
return getPalindrome(number, value+1);	
}


public String showPalindrome(int number)
{
	String saved = String.valueOf(number);
return number+""+saved.charAt(0);	
}


public Date getDate(Date input,long value) {
	
	long oldValue = input.getTime();
	long ans = oldValue + value;
	Date savedDate = new Date(ans);
	SimpleDateFormat sdf = new SimpleDateFormat("DD MMM YYYY HH:MM:SS SSS EEE");
	//String date = sdf.format(ans);
	//System.out.println(date);
return savedDate;	
}

}
