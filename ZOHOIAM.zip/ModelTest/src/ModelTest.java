import java.util.Scanner;

public class ModelTest {

	public static void main(String[] args) {
		
		Solution solCall = new Solution();
		
		
		Scanner inputCall = new Scanner(System.in);
		
		int number = inputCall.nextInt();
		
		
		
		switch(number)
		{
			case 1:
			{
				String str1 = "Hello from here";
				String str2 = "reHello from he";
				System.out.println(solCall.rotation(str1, str2));
				break;
			}
			
			case 2:
			{
				int arr[] = {0,14,0,4,7,8,3,5,7};
				System.out.println(solCall.sumOfPair(arr, 11));
				break;
			}
			
			case 3:
			{
				int arr[] = {-1,-2,-3,-4};
				System.out.println(solCall.maximumSum(arr, 4));
				break;
			}
			
			case 4:
			{
				
				break;
			}
		}
		
		

		

		
	inputCall.close();	
	}

}
