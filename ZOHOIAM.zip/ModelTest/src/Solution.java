import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Solution 
{
public boolean rotation(String str1,String str2)
{
	if(str1.equals(str2.substring(2)+str2.substring(0,2)))
	{
		return true;
	}
return false;
}

public List<String> sumOfPair(int arr[],int sum)
{
	String saved = "";
	List<String> ans = new ArrayList<>();
	
	for(int i = 0; i < arr.length;i++)
	{
		for(int j = 1; j < arr.length;j++)
		{
		if(j > i)
		{	
		if(sum == (arr[i] + arr[j]))
		{
			saved = "("+arr[j] +","+ arr[i]+")";
			ans.add(saved);
		}
		}
		}
		
	}
return ans;
}

public int maximumSum(int arr[],int n)
{
	int max = Integer.MIN_VALUE;
	int dummy = 0;
	for(int i = 0; i < n; i++)
	{
		dummy += arr[i];  
		max = Math.max(max, dummy);
	}
return max;	
}


public String lookAndSequence(int number)
{
	if(number == 1)
	{
		return "1";
	}
	
	StringBuilder saved = new StringBuilder();
	
	String output= lookAndSequence(number - 1);
	
	
	
	return null;
	
}
}
