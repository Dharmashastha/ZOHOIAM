package inheritance;

public abstract class BirdAbstract 
{
	public void fly()
	{
		System.out.println("Zoho");
	}
	public void speak()
	{
		System.out.println("Hello");
	}
}
