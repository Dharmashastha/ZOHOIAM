package inheritance;

public class Duck extends Bird 
{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Thank you");
	}

}
