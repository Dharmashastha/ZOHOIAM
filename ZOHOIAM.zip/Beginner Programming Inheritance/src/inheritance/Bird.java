package inheritance;

public abstract class Bird 
{
	abstract void fly();
	public void speak()
	{
		System.out.println("Welcome");
	}
}
