package equalnumber;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EqualNumber {

	public boolean equalNumber(int array[], int n, int difference) {
		List<Integer> output = new ArrayList<>();
		Arrays.sort(array);
		for(int i = 0; i < n; i++)
		{
			output.add(array[i]);
		}
		for(int i = 0; i < n; i++)
		{
			int dummy = abs(difference - array[i]);
			if(output.contains(dummy))
			{
				return true;
			}
		}
		return false;
//		for (int i = 0; i < n; i++) {
//			int dummy = abs(difference - array[i]);
//			if(contains(array,dummy))
//			{
//				return true;
//			}
//		}
//		return false;
	}
	
//	boolean contains(int array[],int number)
//	{
//		for(int i = 0; i < array.length; i++)
//		{
//			if(array[i] == number)
//			{
//				return true;
//			}
//		}
//	return false;	
//	}

	int abs(int number) {
		if (number < 0) {
			return -number;
		}
		return number;
	}

	public static void main(String[] args) {
		EqualNumber equalCall = new EqualNumber();
		int array[] = {90, 70, 20, 80, 50};
		System.out.println(equalCall.equalNumber(array, array.length, 50));
	}

}
