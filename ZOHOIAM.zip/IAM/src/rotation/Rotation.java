package rotation;

public class Rotation {

	public int numberofRotation(int array[], int n, int rotate) {
		
		
		rotate=rotate%n;
		
		//for(int i=0;i<n;i++)
		//{
			int index=n-rotate+0%n;
			return array[index];
		//}
		
		
		//int temp = 0;
//		while (rotate > 0) {// (n - rotate + i) % n
//			for (int i = n - 1; i > 0; i--) {
//				temp = array[i];
//				array[i] = array[i - 1];
//				array[i - 1] = temp;
//			}
//			rotate--;
//		}
	}

	public static void main(String[] args) {
		Rotation call = new Rotation();
		int array[] = { 1,2,3,4,5};
		System.out.println(call.numberofRotation(array, array.length, 4));
	}

}
