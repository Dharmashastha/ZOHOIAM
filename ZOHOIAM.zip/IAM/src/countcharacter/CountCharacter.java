package countcharacter;

import java.util.Objects;
import java.util.Scanner;

public class CountCharacter {

	public String countCharacter(String str) throws Exception {
		if (Objects.isNull(str) || str.isEmpty()) {
			throw new Exception("Input is Null/Empty");
		}
		char saved[] = toCharArray(str);
		saved = mergeSort(saved);
		int count = 1;
		// int length = str.length();

		StringBuilder output = new StringBuilder();
		int i = 0;
		for (; i < saved.length - 1; i++) {
			char ch = saved[i];
			if (ch == saved[i + 1]) {
				count++;
			} else {
				output.append(ch).append(count);
				count = 1;
			}
			// && str.charAt(i) == str.charAt(i+1)
		}
		if (i == saved.length - 1) {
			output.append(saved[i]).append(count);
		}
		return output.toString();
	}

	char[] toCharArray(String str) {
		int length = str.length();
		char[] saved = new char[length];
		for (int i = 0; i < length; i++) {
			saved[i] = str.charAt(i);
		}
		return saved;
	}

	char[] mergeSort(char[] array) {
		if (array.length == 1) {
			return array;
		}

		int midValue = array.length / 2;

		char left[] = mergeSort(copyOfRange(array, 0, midValue));
		char right[] = mergeSort(copyOfRange(array, midValue, array.length));

		return merge(left, right);
	}

	char[] merge(char[] left, char right[]) {
		char[] saved = new char[left.length + right.length];
		int i = 0, j = 0, k = 0;

		while (i < left.length && j < right.length) {
			if (left[i] < right[j]) {
				saved[k++] = left[i++];
			} else {
				saved[k++] = right[j++];
			}
		}

		while (i < left.length) {
			saved[k++] = left[i++];
		}
		while (j < right.length) {
			saved[k++] = right[j++];
		}
		return saved;
	}

	char[] copyOfRange(char[] array, int fromIndex, int toIndex) {
		char[] saved = new char[toIndex - fromIndex];
		int k = 0;
		for (int i = fromIndex; i < toIndex; i++) {
			saved[k++] = array[i];
		}
		return saved;
	}

	public static void main(String[] args) {

		CountCharacter countCall = new CountCharacter();

		Scanner inputCall = new Scanner(System.in);

		System.out.println("Enter the String");
		String str = inputCall.nextLine();
		try {
			System.out.println(countCall.countCharacter(str));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			// e.printStackTrace();
		}
		inputCall.close();
	}

}
