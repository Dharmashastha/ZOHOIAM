package maxsum;

import java.util.Arrays;

public class MaxSum {

	public int maxSum(int arr[], int n) {
		Arrays.sort(arr);
		int sum = 0;
		int max = Integer.MIN_VALUE;
		
		for (int i = 0; i < n; i++) {
			sum += arr[i];
			max = maxValue(max, sum);
			if (sum < 0) {
				sum = 0;
			}
		}
		return max;
	}

	int maxValue(int a, int b) {
		if (a > b) {
			return a;
		}
		return b;
	}

	public static void main(String[] args) {
		MaxSum sumCall = new MaxSum();
		
		//Scanner inputCall = new Scanner(System.in);
		
		//System.out.println("Enter the ArrayLength");
		//int length = Integer.parseInt(inputCall.nextLine());
		int array[] = {-1,-2,-3,-5,-4};
		System.out.println(sumCall.maxSum(array, array.length));
	}

}
