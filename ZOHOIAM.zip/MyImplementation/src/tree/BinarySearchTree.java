package tree;

import java.util.Scanner;

public class BinarySearchTree {

	public Node insert(Node root, int value) {
		if (root == null) {
			return new Node(value);
		}

		if (value < root.data) {
			root.left = insert(root.left, value);
		}
		if (value > root.data) {
			root.right = insert(root.right, value);
		}
		return root;
	}

	public Node trimBST(Node root, int low, int high) {
		if (root == null) {
			return null;
		}

		if (root.data < low) {
			return trimBST(root.right, low, high);
		}
		if (root.data > high) {
			return trimBST(root.left, low, high);
		}

		if (root.left != null) {
			root.left = trimBST(root.left, low, high);
		}

		if (root.right != null) {
			root.right = trimBST(root.right, low, high);
		}
		return root;
	}
	
	public Node searchBST(Node root,int value)
	{
		if(root == null || root.data == value)
		{
			return root;
		}
		
		if(value < root.data)
		{
			return searchBST(root.left, value);
		}
	return searchBST(root.right, value);	
	}
	
	public static void main(String args[]) {
		BinarySearchTree treeCall = new BinarySearchTree();

		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Root Data");
		Node nodeCall = new Node(Integer.parseInt(input.nextLine()));

		System.out.println("Enter the BinarySearchTree Data Length");
		int length = Integer.parseInt(input.nextLine());

		System.out.println("Enter the BinarySearchTree Data");
		for (int i = 0; i < length; i++) {
			treeCall.insert(nodeCall, Integer.parseInt(input.nextLine()));
		}
		System.out.println(treeCall.trimBST(nodeCall, 1, 3));
		//System.out.println(treeCall.searchBST(nodeCall, 2));
		//Node.print(nodeCall);
		input.close();
	}
}
