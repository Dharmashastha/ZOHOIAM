package tree;

public class Node {
	int data;
	Node left;
	Node right;
	
	public Node(int data) {
		this.data = data;
		left = null;
		right = null;
	}
	
	static void print(Node root)
	{
		if(root == null)
		{
			return;
		}
		print(root.left);
		System.out.print(root.data+ " ");
		print(root.right);
	}

	@Override
	public String toString() {
		return "Node [data=" + data + ", left=" + left + ", right=" + right + "]";
	}
	
	
}
