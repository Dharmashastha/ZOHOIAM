package stringbuilder;

public class StringBuilder {

	Object store[] = new Object[16];
	int k = 0;
	
	public StringBuilder append(String str) {
		for(int i = 0; i < str.length(); i++)
		{
			store[k++] = str;
		}
	return this;	
	}
}
