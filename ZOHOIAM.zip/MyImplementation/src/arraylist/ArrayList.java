package arraylist;

import java.util.Arrays;
import java.util.Objects;

public class ArrayList<E> {
	
	private Object[] elementData = {};
	
	private int size = 0;
	
	private int minCapacity = 16;
	
	public ArrayList() {
		elementData = new Object[minCapacity];
	}
	
	
	public void add(E item)
	{
		if(size == minCapacity)
		{
			resizeArrayList();
		}
		elementData[size++] = item;
	}

	public void add(int index,E element)
	{
		if(index > minCapacity)
		{
			throw new IllegalArgumentException("Index :"+ index +" Size :"+ minCapacity);
		}
		elementData[index] = element;
		
	}
	
	public void clear()
	{
		for(int i = 0; i < size; i++)
		{
			elementData[i] = null;
		}
		size = 0;
	}
	
	public boolean contains(Object o)
	{
		for(int i = 0; i < size; i++)
		{
			if(elementData[i] == o)
			{
				return true;
			}
		}
	return false;	
	}
	
	public E get(int index)
	{
		E e = (E)elementData[index];
		return e;
	}
	
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	public E remove(int index)
	{
		if(Objects.isNull(elementData) ||  index < 0 || index >= size)
		{
			return (E) elementData;
		}
		E e = null;
		int k = 0;
		//System.out.println("old elemntDataRemove"+elementData.hashCode());
		Object[] newElementData = new Object[size - 1];
		for(int i = 0; i < size; i++)
		{
			if(i == index)
			{
				e = (E) elementData[i];
				continue;
			}
			newElementData[k++] = elementData[i];
		}
		size = size - 1;
		elementData = newElementData;
		//System.out.println("old elemntDataRemove"+elementData.hashCode());
	return e;	
	}
	
	public int size()
	{
		return size;
	}
	
	public int indexOf(Object o)
	{
		for(int i = 0; i < size; i++)
		{
			if(elementData[i] == o)
			{
				return i;
			}
		}
	return -1;	
	}
	
	public void resizeArrayList()
	{
		minCapacity = 2 * minCapacity;
		Object[] newElementData = elementData;
		//System.out.println("old elemntData"+elementData.hashCode());
		elementData = new Object[minCapacity];
		elementData = Arrays.copyOf(newElementData, minCapacity);
		//System.out.println("new elemntData"+elementData.hashCode());
	}
	
	@Override
	public String toString() {
		return  Arrays.toString(elementData) + "";
	}
}
