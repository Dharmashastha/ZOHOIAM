package arraylist;

public class Controller {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> arrayList = new ArrayList<>();
		
		System.out.println(arrayList.isEmpty());
		
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		arrayList.add(4);
		arrayList.add(5);
		arrayList.add(6);
		arrayList.add(7);
		arrayList.add(9);
		arrayList.add(10);
		arrayList.add(11);
		arrayList.add(12);
		arrayList.add(13);
		arrayList.add(14);
		arrayList.add(15);
		arrayList.add(16);
		arrayList.add(17);
		arrayList.add(18);
		arrayList.add(19);
		arrayList.add(20);

		
		
		
		System.out.println(arrayList);
		//arrayList.add(1, 7);
		
		System.out.println(arrayList);
		
		System.out.println(arrayList.contains(3));
		System.out.println(arrayList.size());
		System.out.println(arrayList.isEmpty());
		System.out.println(arrayList.indexOf(4));
		System.out.println(arrayList.get(1));
		System.out.println(arrayList.remove(0));
		System.out.println(arrayList.indexOf(8));
		System.out.println(arrayList.size());
		System.out.println(arrayList);
	}

}
