import java.util.Scanner;

public class InputCenter {

	Scanner input = new Scanner(System.in);

	public String getString() {
		String name = "";
		try {
			name = input.nextLine();
			if (name == null || name.isEmpty()) {
				throw new Exception("String Can't be Null and Empty");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " Skipping the String input is prohibited");
		}
		return name;
	}

	public int getInt() {
		int number = 0;
		try {
			String strNumber = input.nextLine();
			if (strNumber == null || strNumber.isEmpty()) {
				throw new Exception("number Can't be Null and Empty");
			}
			number = Integer.parseInt(strNumber);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "input number can't be prohibited");
		}
		return number;
	}

	public double getDouble() {
		double number = 0.00;
		try {
			String strNumber = input.nextLine();
			if (strNumber == null || strNumber.isEmpty()) {
				throw new Exception("number Can't be Null and Empty");
			}
			number = Double.parseDouble(strNumber);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "input number can't be prohibited");
		}
		return number;
	}

	public long getLong() {
		long number = 0l;
		try {
			String strNumber = input.nextLine();
			if (strNumber == null || strNumber.isEmpty()) {
				throw new Exception("number Can't be Null and Empty");
			}
			number = Long.parseLong(strNumber);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "input number can't be prohibited");
		}
		return number;
	}

	public char getChar() {
		char character = 0;
		try {
			String strNumber = input.nextLine();
			if (strNumber == null || strNumber.isEmpty()) {
				throw new Exception("character Can't be Null and Empty");
			}
			character = strNumber.charAt(0);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "input character can't be prohibited");
		}
		return character;
	}

}
