
public class Node {
	
	int data;
	Node left,right;
	
	public Node(int val)
	{
		data = val;
		left = null;
		right = null;
	}
	
	public void print(Node root)
	{
		print(root.left);
		System.out.println(root.data);
		print(root.right);
	}
	
}
