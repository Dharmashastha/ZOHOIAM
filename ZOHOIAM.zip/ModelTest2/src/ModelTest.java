import java.util.Map;

public class ModelTest {

	public static void print(Node root) {
		if (root == null) {
			System.out.println("null");
			return;
		}
		System.out.print(root.data);
		print(root.left);
		print(root.right);
	}

	public static void main(String[] args) {
		Solution solCall = new Solution();

		// System.out.println(solCall.palindrome(160));

		// int arr[] = {9,0,-3,-4,88,99};
		// System.out.println(Arrays.toString(solCall.mergeSort(arr)));

		// int arr[] = {1,2,3,7,5};
		// System.out.println(solCall.contiguousSubArray(arr, 5, 12));

		Node nodeCall = new Node(1);

		solCall.insert(nodeCall, 0);
		solCall.insert(nodeCall, 2);

		Node ans = solCall.trimBST(nodeCall, 1, 2);
		print(ans);

		/*
		 * //String ip = "277.111.111.111";
		 * 
		 * //System.out.println(solCall.validateIPv4Address(ip));
		 * 
		 * int array[] = {6,6,6,6,6,6};
		 * System.out.println(solCall.numberDuplicate(array, 6)); // // int mat[][] = //
		 * { // {1,2,3}, // {4,5,6}, // {7,8,9} // }; // solCall.matrix(mat, 3);
		 */ }

	public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
		if (o1.getValue() > o2.getValue()) {
			return -1;
		} else if (o1.getValue() == o2.getValue()) {
			if (o1.getKey() > o2.getKey()) {
				return 1;
			} else {
				return -1;
			}
		} else if (o1.getValue() < o2.getValue()) {
			return 1;
		}
		return Integer.MIN_VALUE;
	}
}
