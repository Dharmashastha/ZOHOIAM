import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Solution 
{

	int count = 0;

public Node insert(Node root,int value)
{
	if(root == null)
	{
		return new Node(value);
	}
	
	if(value < root.data)
	{
		root.left = insert(root.left, value);
	}
	if(value > root.data)
	{
		root.right = insert(root.right, value);
	}
return root;	
}
	
public Node trimBST(Node root,int low,int high)
{
	if(root == null)
	{
		return null;
	}
	
	if(low > root.data)
	{
		return trimBST(root.right, low, high);
	}
	
	if(high < root.data)
	{
		return trimBST(root.left, low, high);
	}
	
	if(root.left != null)
	{
		root.left = trimBST(root.left, low, high);
	}
	
	if(root.right != null)
	{
		root.right = trimBST(root.right, low, high);
	}
return root;	
}

public int palindrome(int number)
{
	
	return getPalindrome(number, 10);
}

public int getPalindrome(int number,int value)
{
	StringBuilder ans = new StringBuilder(value+"");
	
	if(Integer.parseInt(ans.reverse().toString()) == value)
	{
		count++;
	}
	
	if(count == number)
	{
		return value;
	}
return getPalindrome(number, value+1);	
}
	
	
public int[] mergeSort(int array[])
{
	if(array.length == 1)
	{
		return array;
	}
	
	int midValue = array.length / 2;
	
	int left[]  = mergeSort(Arrays.copyOfRange(array, 0, midValue));
	int right[] = mergeSort(Arrays.copyOfRange(array, midValue, array.length));
	
return merge(left,right);	
}

public int[] merge(int left[],int right[])
{
	int[] saved = new int[left.length + right.length];
	int i = 0,j = 0,k = 0;
	
	while(i < left.length && j < right.length)
	{
		if(left[i] < right[j])
		{
			saved[k++] = left[i++];
		}
		else
		{
			saved[k++] = right[j++];
		}
	}

	while(i < left.length)
	{
		saved[k++] = left[i++];
	}
	while(j < right.length)
	{
		saved[k++] = right[j++];
	}
return saved;		
}
	
	
public String contiguousSubArray(int array[],int n,int sum)
{
	int dummy;
	String saved = ""; 
	for(int i = 0; i < n; i++)
	{
		dummy = array[i];
		for(int j = i+1; j < n;j++)
		{
			dummy += array[j];
			if(dummy == sum)
			{
				
				saved = (i+1) + " " + (j+1);
				return saved;
			}
			else if(dummy > sum)
			{
				break;
			}
		}
		
	}
return saved;	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * public boolean validateIPv4Address(String ipv4) { String[] dummy =
	 * ipv4.split("\\."); boolean flag = false;
	 * 
	 * if(dummy.length == 4) { for(int i = 0; i < dummy.length; i++) {
	 * if(dummy[i].length() >= 3) { int saved = Integer.parseInt(dummy[i]); if(0 <
	 * saved && saved <= 255) { flag = true; } else { return false; } } else {
	 * return false; }
	 * 
	 * }
	 * 
	 * } else { return false; }
	 * 
	 * return flag; }
	 * 
	 * 
	 * public List<String> numberDuplicate(int array[],int n) { List<String> ans =
	 * new ArrayList<>(); Arrays.sort(array); int count = 1; String saved = "";
	 * 
	 * for(int i = 0; i < n - 1; i++) { if(array[i] == array[i+1]) { count++; } else
	 * { saved = array[i] + "-" + count; ans.add(saved); count = 1; } } count = 1;
	 * if(array[n - 2] == array[n - 1]) { count++; saved = array[n - 2] + "-" +
	 * count; ans.add(saved); } else { saved = array[n - 1] + "-" + count;
	 * ans.add(saved); } return ans; }
	 * 
	 * public void matrix(int mat[][],int n) { for(int i = n - 1; i >= 0; i--) {
	 * for(int j = 0; j < mat[0].length; j++) { System.out.print(mat[j][i]+" "); }
	 * System.out.println(); } }
	 */

}
