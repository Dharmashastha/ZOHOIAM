package test2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class LengthLongestSubString {

	public int longestSubString(String str) throws Exception {
		if (Objects.isNull(str) || str.isEmpty()) {
			throw new Exception("String is Null/Empty");
		}

		List<Character> saved = new ArrayList<>();
		int count = 0;
		int max = Integer.MIN_VALUE;
		int length = str.length();

		for (int i = 0; i < length;) {
			char ch = str.charAt(i);
			if (saved.contains(ch)) {
				saved.remove(0);
			} else {
				saved.add(ch);
				count = saved.size();
				max = Math.max(max, count);
				i++;
			}
		}
		return max;
	}

	public static void main(String[] args) {

		LengthLongestSubString longCall = new LengthLongestSubString();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the String");
		String str = input.nextLine();
		try {
			System.out.println(longCall.longestSubString(str));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			// e.printStackTrace();
		}
		input.close();
	}

}
