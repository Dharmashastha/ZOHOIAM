package test2;

import java.util.Scanner;

public class FindDate {

	public int noOfDays(int d1, int m1, int y1, int d2, int m2, int y2) throws Exception {
		
		if(d1 > 31 || m1 > 12 || d2 > 31 || m2 > 12)
		{
			throw new Exception("Check Your Date");
		}
		
		int month[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		int n1 = d1 + 365 * y1;

		for (int i = 0; i < m1 - 1; i++) {
			n1 += month[i];
		}

		n1 += noOfLeapDays(y1, m1);

		int n2 = d2 + 365 * y2;

		for (int i = 0; i < m2 - 1; i++) {
			n2 += month[i];
		}

		n2 += noOfLeapDays(y2, m2);

		return Math.abs(n2 - n1);
	}

	private int noOfLeapDays(int year, int month) {
		if (month <= 2) {
			year--;
		}
		return year / 4 - year / 100 + year / 400;
	}

	public static void main(String[] args) {

		FindDate dateCall = new FindDate();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the Date 1");
		int d1 = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Month 1");
		int m1 = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Year 1");
		int y1 = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Date 2");
		int d2 = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Month 2");
		int m2 = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Year 2");
		int y2 = Integer.parseInt(input.nextLine());
		try {
			System.out.println(dateCall.noOfDays(d1, m1, y1, d2, m2, y2));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		input.close();
	}

}
