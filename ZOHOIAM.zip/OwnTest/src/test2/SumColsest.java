package test2;

import java.util.Scanner;

public class SumColsest {

	public String sumClosestNumber(int arr[], int n, int x) {
		int max = Integer.MIN_VALUE;
		String saved = "";

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				int temp = Math.abs(arr[i] + arr[j]);
				if (temp < x) {
					if (max < temp) {
						max = Math.max(max, temp);
						saved = arr[i] + " " + arr[j];
					}
				}
			}
		}
		return saved;
	}

	public static void main(String[] args) {

		SumColsest sumCall = new SumColsest();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the ArrayLength");
		int length = Integer.parseInt(input.nextLine());

		int array[] = new int[length];

		System.out.println("Enter the array Data");
		for (int i = 0; i < array.length; i++) {
			array[i] = Integer.parseInt(input.nextLine());
		}

		System.out.println("Enter the sumColsest Number");
		int colseNumber = Integer.parseInt(input.nextLine());

		System.out.println(sumCall.sumClosestNumber(array, length, colseNumber));
		input.close();
	}

}
