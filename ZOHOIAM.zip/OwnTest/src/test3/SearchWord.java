package test3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SearchWord {

	int x[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
	int y[] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	public List<List<Integer>> searchWord(char[][] grid, String word) {
		List<List<Integer>> output = new ArrayList<>();

		for (int row = 0; row < grid.length; row++) {
			for (int col = 0; col < grid[0].length; col++) {
				if (search(grid, row, col, word)) {
					List<Integer> saved = new ArrayList<>();
					saved.add(row);
					saved.add(col);
					output.add(saved);
				}
			}
		}
		return output;
	}

	private boolean search(char[][] grid, int row, int col, String word) {

		if (grid[row][col] != word.charAt(0)) {
			return false;
		}

		int wordLength = word.length();

		for (int dir = 0; dir < 8; dir++) {
			int rowd = row + x[dir];
			int cold = col + y[dir];
			int k;

			for (k = 1; k < wordLength; k++) {
				if (rowd < 0 || cold < 0 || rowd >= grid.length || cold >= grid[0].length) {
					break;
				}

				if (grid[rowd][cold] != word.charAt(k)) {
					break;
				}
				rowd += x[dir];
				cold += y[dir];
			}
			if (k == wordLength) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {

		SearchWord searchCall = new SearchWord();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the Row Length");
		int rLength = Integer.parseInt(input.nextLine());
		System.out.println("Enter the Col Length");
		int cLength = Integer.parseInt(input.nextLine());

		char grid[][] = new char[rLength][cLength];

		for (int i = 0; i < rLength; i++) {
			System.out.println("Enter " + i + " Array Data");
			for (int j = 0; j < rLength; j++) {
				grid[i][j] = input.nextLine().charAt(0);
			}
		}

		System.out.println("Enter search Word");
		String word = input.nextLine();

		System.out.println(searchCall.searchWord(grid, word));
		input.close();
	}

}
