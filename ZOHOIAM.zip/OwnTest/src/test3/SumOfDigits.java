package test3;

import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeMap;

public class SumOfDigits {

	public int[] sumOfDigitsNumber(int arr[], int n) {
		TreeMap<Integer, Integer> output = new TreeMap<>();
		for (int i = 0; i < arr.length; i++) {
			output.put(sumOfDigits(arr[i]), arr[i]);
		}

		int i = 0;
		for (int saved : output.keySet()) {
			arr[i++] = output.get(saved);
		}
		return arr;
	}

	private int sumOfDigits(int number) {
		int sum = 0, rem;
		while (number != 0) {
			rem = number % 10;
			sum += rem;
			number /= 10;
		}
		return sum;
	}

	public static void main(String[] args) {

		SumOfDigits sumCall = new SumOfDigits();

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the array Length");
		int length = Integer.parseInt(input.nextLine());

		int array[] = new int[length];

		System.out.println("Enter the Array Data");
		for (int i = 0; i < array.length; i++) {
			array[i] = Integer.parseInt(input.nextLine());
		}

		System.out.println(Arrays.toString(sumCall.sumOfDigitsNumber(array, length)));
		input.close();
	}

}
