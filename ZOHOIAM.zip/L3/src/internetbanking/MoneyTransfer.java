package internetbanking;

public class MoneyTransfer 
{

}
