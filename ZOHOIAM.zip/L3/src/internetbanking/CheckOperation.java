package internetbanking;



public class CheckOperation 
{
	Cache cacheCall = new Cache();

}
