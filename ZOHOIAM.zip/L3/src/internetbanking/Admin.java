package internetbanking;

public class Admin {

}
