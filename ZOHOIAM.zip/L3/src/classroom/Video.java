package classroom;

public class Video {

	private String subject;
	private String date;
	private int size;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	@Override
	public String toString() {
		return "Video [subject=" + subject + ", date=" + date + ", size=" + size + "]";
	}

}
