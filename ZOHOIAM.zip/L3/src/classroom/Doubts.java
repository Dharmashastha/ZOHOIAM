package classroom;

public class Doubts {

	private String question;
	private String date;
	private String userId;

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Doubts [question=" + question + ", date=" + date + ", userId=" + userId + "]";
	}

}
