package classroom;

public enum Role {
	STUDENT,FACULTY,ADMIN
}
