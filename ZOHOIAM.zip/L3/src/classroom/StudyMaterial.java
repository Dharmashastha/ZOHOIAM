package classroom;

public class StudyMaterial {

	private String userId;
	private PowerPoint ppt;
	private Video video;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public PowerPoint getPpt() {
		return ppt;
	}

	public void setPpt(PowerPoint ppt) {
		this.ppt = ppt;
	}

	public Video getVideo() {
		return video;
	}

	public void setVideo(Video video) {
		this.video = video;
	}
	
	@Override
	public String toString() {
		return "StudyMaterial [userId=" + userId + ", ppt=" + ppt + ", video=" + video + "]";
	}

}
