package classroom;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class VirtualClassroomLayer {

	Map<String, ClassroomDetails> dataStore = new HashMap<>();
	Map<String, Doubts> doubtStore = new HashMap<>();
	Map<String, Answer> answerStore = new HashMap<>();
	Map<String, StudyMaterial> materialStore = new HashMap<>();

	public void addClassroomDetails(ClassroomDetails classCall) {
		dataStore.put(classCall.getUserId(), classCall);
	}

//	public void addDoubts(Doubts doubtCall) {
//		doubtStore.put(doubtCall.getQuestion(), doubtCall);
//	}

//	public void addAnswer(Answer ansCall) {
//		answerStore.put(ansCall.getQuestion(), ansCall);
//	}

//	public void addMaterial(StudyMaterial studyCall) {
//		materialStore.put(studyCall.getUserId(), studyCall);
//	}

	public void checkerUserId(String userId) throws Exception {
		if (Objects.isNull(dataStore.get(userId))) {
			throw new Exception("Wrong UserId");
		}
	}

	public boolean loginClassroom(String userId, String password) throws Exception {
		checkerUserId(userId);
		ClassroomDetails classCall = dataStore.get(userId);
		if (classCall.getUserId().equals(userId) && classCall.getPassword().equals(password)) {
			return true;
		}
		return false;
	}

	public Map<String, StudyMaterial> getStudyMaterial() {
		return materialStore;
	}

	public String getStudyMaterial(String userId) throws Exception {
		checkerUserId(userId);
		StudyMaterial studyCall = materialStore.get(userId);
		return studyCall.getPpt() + "    " + studyCall.getVideo();
	}

	public String askDoubts(Doubts doubtsCall) throws Exception {
		Role role = dataStore.get(doubtsCall.getUserId()).getRole();
		if (role.equals(Role.STUDENT)) {
			doubtStore.put(doubtsCall.getQuestion(), doubtsCall);
		}
		return doubtsCall.getQuestion();
	}

	public Answer showAnswer(String question) {
		Answer ansCall = answerStore.get(question);
		return ansCall;
	}
}
