package classroom;

public class ClassroomDetails {

	private String name;
	private long phoneNumber;
	private String userId;
	private Role role;
	private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Role getRole() {
		return role;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "ClassroomDetails [name=" + name + ", phoneNumber=" + phoneNumber + ", userId=" + userId + ", role="
				+ role + ", password=" + password + "]";
	}

}
